# Change Log

## v0.1.1

- make py3-compatible
- introduce version attribute
