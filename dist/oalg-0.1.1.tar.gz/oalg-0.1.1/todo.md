# To do

- implement class Hist (online algorithm for creating a histogram)
- test early Python 2 compatibility, decrease version requirement (should be compatible with almost any Python version)
